import package

def test_me():
    assert package.add_me(3,6) == 9
