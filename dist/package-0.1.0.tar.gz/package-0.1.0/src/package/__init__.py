"""
package - a simple practice module
"""

__version__ = "0.1.0"

from .math_utils import add_me, multiply_me
