def add_me(a,b):
    sum = a + b
    return sum


def multiply_me(a,b):
    product =a *b
    return product
    
